import { Router } from "express";
import { login, unlockScreen } from "./auth.controller";
import { tenantMiddleware } from "../../middleware/tenant.middleware";
import { authMiddleware } from "../../middleware/auth.middleware";

const router = Router();

router.post("/login", login);
router.post("/unlock", tenantMiddleware, authMiddleware, unlockScreen);

export default router;
