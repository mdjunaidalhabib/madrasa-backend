import { db } from "../../config/db";
import { comparePassword } from "../../utils/hash";
import { generateToken } from "../../utils/jwt";

export const loginService = async (email: string, password: string) => {
  /* =========================
     FIND USER
  ========================= */
  const [rows]: any = await db.query(
    "SELECT * FROM users WHERE email=? AND is_active=1",
    [email],
  );

  if (!rows.length) throw new Error("Invalid credentials");

  const user = rows[0];

  /* =========================
     VERIFY PASSWORD
  ========================= */
  const valid = await comparePassword(password, user.password_hash);
  if (!valid) throw new Error("Invalid credentials");

  /* =========================
     LOAD PERMISSIONS
  ========================= */
  const [permRows]: any = await db.query(
    `
    SELECT p.key_name
    FROM permissions p
    JOIN role_permissions rp ON rp.permission_id = p.id
    WHERE rp.role_id = ?
    `,
    [user.role_id],
  );

  const permissions = permRows.map((p: any) => p.key_name);

  /* =========================
     CREATE TOKEN
  ========================= */
  const token = generateToken({
    id: user.id,
    madrasa_id: user.madrasa_id,
    role_id: user.role_id,
  });

  /* =========================
     LOAD ENABLED MODULES
  ========================= */
  const [modRows]: any = await db.query(
    `
    SELECT m.key_name
    FROM madrasa_modules mm
    JOIN modules m ON m.id = mm.module_id
    WHERE mm.madrasa_id = ?
      AND mm.is_enabled = 1
    `,
    [user.madrasa_id],
  );

  const modules = modRows.map((m: any) => m.key_name);

  /* =========================
     RESPONSE
  ========================= */
  return {
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role_id: user.role_id,
    },
    permissions,
    modules,
  };
};
